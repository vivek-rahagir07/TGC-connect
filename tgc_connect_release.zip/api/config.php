<?php
/**
 * TGC Connect - Database Configuration
 * Architecture: PHP + MySQL/MariaDB + PDO + Vanilla JavaScript
 * Configured for Hostinger Deployment (Domain: tgcconnect.in)
 */

// 1. Base Configuration Defaults (Pre-configured for Hostinger Production)
$defaultConfig = [
    // Database Host (Hostinger uses 'localhost')
    'host'        => getenv('DB_HOST') ?: 'localhost',
    
    // Database Port (Standard MySQL port is 3306)
    'port'        => (int) (getenv('DB_PORT') ?: 3306),
    
    // Database Name
    'database'    => getenv('DB_NAME') ?: 'u286523491_Globle_connect',
    
    // Database Username
    'username'    => getenv('DB_USER') ?: 'u286523491_Globle_connect',
    
    // Database Password
    'password'    => getenv('DB_PASS') !== false ? getenv('DB_PASS') : (getenv('DB_PASSWORD') !== false ? getenv('DB_PASSWORD') : 'Beenu@123456#'),
    
    // Character Set
    'charset'     => 'utf8mb4',

    // Attendance Notification Settings
    'notifications' => [
        'admin_whatsapp'         => '+91 87430 88888',
        'admin_email'            => 'tgcconnectglobal@gmail.com',
        'admin_sms_phone'        => '8743088888',    // Admin phone for SMS alerts (10-digit Indian)
        'company_name'           => 'Getting Roots Coaching & Training Pvt. Ltd.',
        'send_whatsapp'          => true,
        'send_email'             => true,
        // Gmail SMTP Settings
        'smtp_host'              => 'smtp.gmail.com',
        'smtp_port'              => 587,
        'smtp_user'              => 'tgcconnectglobal@gmail.com',
        'smtp_password'          => getenv('SMTP_PASSWORD') ?: 'gcozpsiozbtqqkoh',
        // SMS Gateway Settings (Fast2SMS / TextLocal)
        'sms_provider'           => getenv('SMS_PROVIDER') ?: 'fast2sms',    // 'fast2sms' or 'textlocal'
        'sms_api_key'            => getenv('SMS_API_KEY') ?: '',              // API key from Fast2SMS or TextLocal dashboard
        // Optional webhook or automated gateway integration (UltraMsg / Twilio / Meta / Webhook)
        'whatsapp_provider'      => getenv('WHATSAPP_PROVIDER') ?: 'direct',
        'whatsapp_gateway_url'   => getenv('WHATSAPP_GATEWAY_URL') ?: '',
        'whatsapp_gateway_token' => getenv('WHATSAPP_GATEWAY_TOKEN') ?: '',
    ],
];

// 2. Merge private local configuration file if present (ignored from Git)
if (file_exists(__DIR__ . '/config.local.php')) {
    $localConfig = require __DIR__ . '/config.local.php';
    if (is_array($localConfig)) {
        return array_replace_recursive($defaultConfig, $localConfig);
    }
}

return $defaultConfig;
