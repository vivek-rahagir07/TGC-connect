<?php
/**
 * TGC Connect - Local Environment Database Credentials
 * DO NOT COMMIT THIS FILE TO GIT.
 * This file stays private on your local machine and on Hostinger server.
 */

return [
    'host'     => getenv('DB_HOST') ?: 'localhost',
    'port'     => (int) (getenv('DB_PORT') ?: 3306),
    'database' => getenv('DB_NAME') ?: 'u286523491_Globle_connect',
    'username' => getenv('DB_USER') ?: 'u286523491_Globle_connect',
    'password' => getenv('DB_PASS') ?: 'Beenu@123456#',
    'charset'  => 'utf8mb4',
    'notifications' => [
        'smtp_password' => 'gcozpsiozbtqqkoh',
    ],
];
